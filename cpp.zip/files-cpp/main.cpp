#include<fstream>
#include<iostream>
using namespace std;

int main() {
ofstream file;
printf("Enter text: ");
char text[50] = getchar();
cout << (text) << endl;
file.open("file-base");
file << text;
file.close();
}
