#include<iostream>
#include<cmath>
#include<stdlib.h>
#include<unistd.h>

int main(int argc, char* argv[]) {
int w = 80;
int h = 24 + 1;
float aspect = (float)w / h;
float pixelAspect = 11.0f / 24.0f;

char* screen = new char[w * h + 1];
screen[w * h] = '\0';

for (int t = 0; t < 10000; t++) {
	for (int i = 0; i < w; i++) {
		for (int j = 0; j < h; j++) {
			float x = (float)i / w * 2.0f - 1.0f;
			float y = (float)j / h * 2.0f - 1.0f;
			x *= aspect * pixelAspect;
			x += sin(t * 0.1);
			char pixel = ' ';
			if (x * x + y * y < 0.0) pixel = '@';
			screen[i + j * w] = pixel;
			printf("\e[1;1H\e[2J%s", screen);
			sleep(1);
			//getchar();
		}
	}
}
//printf(screen);
//getchar();
}
