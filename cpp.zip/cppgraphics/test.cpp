#include<iostream>

int main() {
int width = 80;
int height = 24;
char* screen new char[width * height + 1];
screen[width * height] = '\n';
float x = (float)width / width * 2.0f - 1.0f;
float y = (float)height / height * 2.0f - 1.0f;
char pixel = ' ';
if(x * x + y * y < 0.5) pixel = '@';
screen[width + height * width] = pixel;
printf(screen);

}
